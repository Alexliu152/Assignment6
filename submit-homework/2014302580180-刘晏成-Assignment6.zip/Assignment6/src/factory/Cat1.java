package factory;

public class Cat1 implements animals {
		
	String name = "Kate";
    int age = 28 ;
	String sexual = "Female";
	String eat = "Fish, Vegetable, Rice";
	String region = "Cat";
	String character = "Moderate";
	
	@Override
	public void run() {
		System.out.println("Name:"+name);
		
		System.out.println("Region:"+region);
		
		System.out.println("Age:"+age+"Months");
		
		System.out.println("Sexual:"+sexual);
		
	    System.out.println("It likes to eat:"+eat);
		
	    System.out.println("Character:"+character);
		
	}

}
