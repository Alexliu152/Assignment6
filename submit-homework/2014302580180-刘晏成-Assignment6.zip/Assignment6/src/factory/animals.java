package factory;

public interface animals {
    public String name = null;
    public int age = 0;
    public String eat = null;
    public String region = null;
    public String character = null;
    public String sexual = null;
    
    public void run();
    
}
