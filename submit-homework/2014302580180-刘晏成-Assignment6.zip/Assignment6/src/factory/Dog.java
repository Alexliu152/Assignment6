package factory;

public class Dog implements animals{
	String name = "Mike";
    int age = 3 ;
	String sexual = "Male";
	String eat = "Meat, Bone";
	String region = "Dog";
	String character = "Moderate, pleasing, loyal";
	
	@Override
	public void run() {
		System.out.println("Name:"+name);
		
		System.out.println("Region:"+region);
		
		System.out.println("Age:"+age+"years");
		
		System.out.println("Sexual:"+sexual);
		
	    System.out.println("It likes to eat:"+eat);
		
	    System.out.println("Character:"+character);
	}
}
